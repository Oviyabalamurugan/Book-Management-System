<ul>
        <li><a href ="alogin.php">Admin Login</a></li>
        <li><a href ="ulogin.php">User Login</a></li>
        <li><a href ="new.php">New User</a></li>
</ul>