<ul>
        <li><a href ="uhome.php">Home</a></li>
        <li><a href ="search_books.php">Search Books</a></li>
        <li><a href ="request.php">Request</a></li>
        <li><a href ="uchangePass.php">Change password</a></li>
        <li><a href ="logout.php">Logout</a></li>
</ul>