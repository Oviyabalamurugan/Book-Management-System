<ul>
        <li><a href ="ahome.php">Home</a></li>
        <li><a href ="view_student.php">View student</a></li>
        <li><a href ="upload_books.php">Upload Books</a></li>
        <li><a href ="view_books.php">View Books</a></li>
        <li><a href ="view_req.php">View Request</a></li>
        <li><a href ="view_comm.php">View comments</a></li>
        <li><a href ="achangePass.php">Change password</a></li>
        <li><a href ="logout.php">Logout</a></li>
</ul>