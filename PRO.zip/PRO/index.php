<!DOTYPE HTML>
<html>
<head>
<title>BOOK MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type ="text/css" href="css/style.css">
</head>
<body>
<div id="container">
<div id="header">
<h1>BOOK MANAGEMENT SYSTEM</h1>
</div>
<div id="wrapper">
    <p><H2>BOOk MANAGEMENT SYTEM USES</H2>
1. Simple & Easy to Use<br>

The Library Management Software is simple, user-friendly, and can be easily integrated with your existing system. The library management system benefits provide online and offline storage, automated backups, and easy upgrades to simplify and enhance the learning process. <br> 

2. Increased Library Engagement<br>

Avoid frustration and tediousness by providing students with 24/7 access to library resources from anywhere, anytime. Library Management Software allows the librarian to maintain all types of books, eBooks, journals, photos, videos, and create events.<br>

3. Efficient Cloud Data Management<br>

Automate, simplify and deploy library database seamlessly to make it easy for your institution to benefit from secure cloud services. Improve efficiency with the automation of various library tasks including acquisition, cataloging, serials management, circulation and reference<br>

4. Highly Secure, Scalable & Reliable<br>

College libraries benefit from scalable infrastructure, role-based secure access, high performance and reliable to ensure seamless access to library database.<br>

5. Mobile Access<br>

The library management system provides mobile access to search the library catalog, schedules, books and resources from anywhere, at any given time via smartphones and tablets.<br>

</p>
    
</div>
<div id="navi">
    <?php
    include "sidebar.php"
    ?>
</div>
<div id="footer">
<p>Copyright &copy; book management 2020</p>
<div>
</div>
</body>
</html>


